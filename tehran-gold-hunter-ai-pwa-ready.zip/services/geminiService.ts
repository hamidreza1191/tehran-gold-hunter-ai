import { GoogleGenAI, Type } from "@google/genai";
import { MarketData, AISignal, SignalAction } from "../types";
import { SYSTEM_INSTRUCTION, GEMINI_MODEL } from "../constants";

const genAI = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    action: {
      type: Type.STRING,
      enum: ["BUY", "SELL", "HOLD", "STRONG_BUY", "STRONG_SELL"],
      description: "The trading action recommendation.",
    },
    confidence: {
      type: Type.NUMBER,
      description: "Confidence level between 0 and 100.",
    },
    entryPrice: {
      type: Type.NUMBER,
      description: "Recommended entry price.",
    },
    stopLoss: {
      type: Type.NUMBER,
      description: "Recommended stop loss price.",
    },
    takeProfit: {
      type: Type.NUMBER,
      description: "Recommended take profit price.",
    },
    reasoning: {
      type: Type.STRING,
      description: "Explanation of the signal in Persian (Farsi).",
    },
  },
  required: ["action", "confidence", "reasoning", "stopLoss", "takeProfit", "entryPrice"],
};

export const getAiSignal = async (recentHistory: MarketData[]): Promise<AISignal | null> => {
  try {
    const minimalHistory = recentHistory.map(h => ({
      p: h.price,
      t: new Date(h.timestamp).toLocaleTimeString(),
    }));

    const currentPrice = recentHistory[recentHistory.length - 1].price;

    const prompt = `
      Current Market Data (Tehran Gold / Ab Shodeh): ${JSON.stringify(minimalHistory)}
      Current Price: ${currentPrice}.
      
      Task: Analyze the micro-structure and volatility.
      PREDICT the next move.
      
      CRITICAL LANGUAGE REQUIREMENT:
      The 'reasoning' field MUST BE IN PERSIAN (FARSI).
      Write like a professional Iranian gold trader ("Ab Shodeh" market style).
      Use terms like "Hemayat" (Support), "Moghavemat" (Resistance), "Shekast" (Breakout), "Poolback".
      
      Output Rules:
      1. Action: Be aggressive. If there is momentum, signal BUY or SELL. Avoid HOLD unless market is dead flat.
      2. Entry Price: Current price or slightly better limit.
      3. Stop Loss: Tight, for scalping.
      4. Take Profit: Realistic scalp target.
    `;

    const response = await genAI.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.6,
      },
    });

    const text = response.text;
    if (!text) return null;

    const data = JSON.parse(text);

    return {
      id: crypto.randomUUID(),
      timestamp: Date.now(),
      action: data.action as SignalAction,
      confidence: data.confidence,
      entryPrice: data.entryPrice || currentPrice,
      stopLoss: data.stopLoss,
      takeProfit: data.takeProfit,
      reasoning: data.reasoning,
      isAggressive: data.confidence > 75,
    };

  } catch (error) {
    console.error("AI Signal Error:", error);
    return {
      id: "fallback-" + Date.now(),
      timestamp: Date.now(),
      action: SignalAction.HOLD,
      entryPrice: 0,
      stopLoss: 0,
      takeProfit: 0,
      confidence: 0,
      reasoning: "سیستم در حال بازیابی ارتباط با مغز متفکر است...",
      isAggressive: false
    };
  }
};