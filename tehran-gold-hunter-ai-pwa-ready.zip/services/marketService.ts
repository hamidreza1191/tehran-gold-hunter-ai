import { MarketData } from '../types';
import { INITIAL_PRICE } from '../constants';

let currentPrice = INITIAL_PRICE;
let lastUpdate = Date.now();

// Simulation logic (Random Walk with Momentum)
export const simulateMarketStep = (): MarketData => {
  const now = Date.now();
  // Volatility factor
  const volatility = Math.random() * 0.002; 
  const direction = Math.random() > 0.48 ? 1 : -1; 
  
  const change = currentPrice * volatility * direction;
  currentPrice += change;
  lastUpdate = now;

  return {
    timestamp: now,
    price: Math.floor(currentPrice),
    change: Math.floor(change),
    changePercent: (change / (currentPrice - change)) * 100,
    high: Math.floor(currentPrice * 1.001),
    low: Math.floor(currentPrice * 0.999),
    volatility: Math.abs(change) * 10, 
  };
};

export const fetchRealMarketData = async (url: string): Promise<MarketData | null> => {
  // Helper to process the response data
  const processData = (json: any): MarketData | null => {
    let dataItem = json;

    // Handle APIs that return a list (like the one provided which has 'list/melted-gold')
    if (Array.isArray(json)) {
      dataItem = json[0]; // Assume first item is latest
    } else if (json.data && Array.isArray(json.data)) {
      dataItem = json.data[0];
    } else if (json.items && Array.isArray(json.items)) {
      dataItem = json.items[0];
    }

    // Adapt fields from PersianApi or generic structure
    // Common fields: 'p', 'price', 'value', 'last', 'rate'
    const rawPrice = dataItem.price || dataItem.value || dataItem.last || dataItem.p || dataItem.rate;
    
    if (!rawPrice) return null;

    let price = Number(rawPrice);
    
    // HEURISTIC: Convert Toman to Rial if necessary.
    // Ab Shodeh is typically ~19-20 million Toman (~200 million Rial).
    // If the value is less than 100,000,000, it is likely in Tomans.
    // The user explicitly requested "Rial basis".
    if (price < 100000000) {
      price = price * 10;
    }

    let high = Number(dataItem.high || dataItem.max || price * 1.001);
    let low = Number(dataItem.low || dataItem.min || price * 0.999);
    
    // Adjust high/low if they were also in Tomans
    if (high < 100000000) high *= 10;
    if (low < 100000000) low *= 10;
    
    // Calculate change if not provided
    const prevPrice = currentPrice; // Use our local state as previous if API doesn't give change
    
    let change = dataItem.change ? Number(dataItem.change) : (price - prevPrice);
    let changePercent = dataItem.changePercent ? Number(dataItem.changePercent) : 0;
    
    // Fallback change calculation
    if (!dataItem.changePercent && prevPrice !== 0 && Math.abs(price - prevPrice) > 0) {
        change = price - prevPrice;
        changePercent = (change / prevPrice) * 100;
    }

    // Update simulation state so if we switch back and forth it's smooth
    currentPrice = price;

    return {
      timestamp: Date.now(),
      price: price,
      change: change,
      changePercent: changePercent,
      high: high,
      low: low,
      volatility: Math.abs(changePercent) * 100 + 20, // Synthetic volatility score
    };
  };

  try {
    // 1. Try Direct Connection
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: { 'Accept': 'application/json' },
      });
      if (response.ok) {
        const json = await response.json();
        return processData(json);
      }
    } catch (e) {
      // Direct fetch failed (likely CORS), proceed to proxy fallback
    }

    // 2. Try Proxy Connection (CORS Bypass)
    // Using allorigins.win as a reliable CORS proxy for JSON data
    const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
    const responseProxy = await fetch(proxyUrl);
    
    if (responseProxy.ok) {
       const json = await responseProxy.json();
       return processData(json);
    }
    
    return null;

  } catch (error) {
    // Swallow error to prevent UI crash, just return null to trigger simulation fallback
    return null;
  }
};