import React, { useState } from 'react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUrl: string;
  onSave: (url: string) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, currentUrl, onSave }) => {
  const [url, setUrl] = useState(currentUrl);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="bg-dark-card border border-dark-700 w-full max-w-md rounded-2xl shadow-2xl p-6 relative">
        <h2 className="text-xl font-bold text-white mb-4">تنظیمات اتصال به بازار</h2>
        
        <div className="mb-6">
          <label className="block text-gray-400 text-sm mb-2">
            API URL بازار ایران (اختیاری)
          </label>
          <input 
            type="text" 
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://api.example.com/gold-price"
            className="w-full bg-dark-900 border border-dark-700 rounded-lg p-3 text-white focus:border-gold-500 focus:outline-none focus:ring-1 focus:ring-gold-500 dir-ltr text-left font-mono"
          />
          <p className="text-xs text-gray-500 mt-2 text-justify leading-5">
            اگر لینک API خود را وارد کنید، هوش مصنوعی روی داده‌های واقعی آن لینک کار می‌کند. اگر خالی بگذارید، از حالت «شبیه‌ساز حرفه‌ای» استفاده می‌کند.
          </p>
        </div>

        <div className="flex space-x-3 space-x-reverse justify-end">
          <button 
            onClick={onClose}
            className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
          >
            انصراف
          </button>
          <button 
            onClick={() => { onSave(url); onClose(); }}
            className="px-6 py-2 bg-gold-600 hover:bg-gold-500 text-black font-bold rounded-lg transition-colors shadow-[0_0_15px_rgba(234,179,8,0.4)]"
          >
            ذخیره و اتصال
          </button>
        </div>
      </div>
    </div>
  );
};
