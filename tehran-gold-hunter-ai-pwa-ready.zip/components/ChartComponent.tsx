import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { MarketData } from '../types';

interface ChartComponentProps {
  data: MarketData[];
}

export const ChartComponent: React.FC<ChartComponentProps> = ({ data }) => {
  const chartData = data.map(d => ({
    time: new Date(d.timestamp).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    value: d.price,
  }));

  // Calculate domain for Y-axis to make chart look dynamic
  const prices = data.map(d => d.price);
  const minPrice = Math.min(...prices);
  const maxPrice = Math.max(...prices);
  const buffer = (maxPrice - minPrice) * 0.1;

  return (
    <div className="h-[350px] w-full bg-dark-card rounded-2xl border border-dark-700 p-4 relative">
       <div className="absolute top-4 right-4 z-10">
         <span className="bg-dark-900/80 text-gray-400 px-3 py-1 rounded-md text-xs font-mono border border-dark-700">
           نمودار لحظه‌ای
         </span>
       </div>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={chartData}>
          <defs>
            <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#EAB308" stopOpacity={0.3}/>
              <stop offset="95%" stopColor="#EAB308" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" vertical={false} />
          <XAxis 
            dataKey="time" 
            stroke="#6b7280" 
            tick={{fontSize: 10, fill: '#6b7280'}}
            tickMargin={10}
            minTickGap={30}
          />
          <YAxis 
            domain={[minPrice - buffer, maxPrice + buffer]} 
            stroke="#6b7280"
            orientation="right"
            tick={{fontSize: 10, fill: '#6b7280'}}
            tickFormatter={(value) => new Intl.NumberFormat('en-US').format(value)}
            width={80}
          />
          <Tooltip 
            contentStyle={{ backgroundColor: '#0A0A0A', borderColor: '#333', color: '#fff' }}
            itemStyle={{ color: '#FACC15' }}
            formatter={(value: number) => [new Intl.NumberFormat('fa-IR').format(value), 'قیمت']}
          />
          <Area 
            type="monotone" 
            dataKey="value" 
            stroke="#EAB308" 
            strokeWidth={2}
            fillOpacity={1} 
            fill="url(#colorValue)" 
            isAnimationActive={false} // Disable animation for smoother real-time updates
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};
