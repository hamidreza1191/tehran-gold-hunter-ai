import React from 'react';
import { MarketData } from '../types';

interface PriceTickerProps {
  data: MarketData;
}

const formatPrice = (price: number) => {
  return new Intl.NumberFormat('fa-IR').format(price);
};

export const PriceTicker: React.FC<PriceTickerProps> = ({ data }) => {
  const isUp = data.change >= 0;
  // Matching the image colors: Cyan for positive, Rose for negative
  const changeColor = isUp ? 'text-[#14b8a6]' : 'text-rose-500'; 
  const changeText = data.changePercent.toFixed(2) + '%';

  return (
    <div className="relative w-full rounded-3xl bg-[#1e1e1e] border border-[#333] p-8 shadow-2xl flex flex-col items-center">
      
      {/* Icon Section */}
      <div className="relative mb-4">
        <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center border-4 border-[#1e1e1e] shadow-[0_0_0_1px_#333] z-10 relative">
          <svg width="60" height="60" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g filter="url(#filter0_d)">
              {/* Stack of Gold Bars */}
              <rect x="14" y="28" width="36" height="12" rx="2" fill="#FFD700" stroke="#B8860B" strokeWidth="2"/>
              <rect x="18" y="18" width="28" height="12" rx="2" fill="#FFD700" stroke="#B8860B" strokeWidth="2"/>
              <rect x="22" y="8" width="20" height="12" rx="2" fill="#FFD700" stroke="#B8860B" strokeWidth="2"/>
              {/* Shines */}
              <path d="M26 12L38 12" stroke="#FFFACD" strokeWidth="2" strokeLinecap="round"/>
              <path d="M22 22L42 22" stroke="#FFFACD" strokeWidth="2" strokeLinecap="round"/>
              <path d="M18 32L46 32" stroke="#FFFACD" strokeWidth="2" strokeLinecap="round"/>
            </g>
            <defs>
              <filter id="filter0_d" x="10" y="8" width="44" height="40" filterUnits="userSpaceOnUse" colorInterpolationFilters="sRGB">
                <feFlood floodOpacity="0" result="BackgroundImageFix"/>
                <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
                <feOffset dy="2"/>
                <feGaussianBlur stdDeviation="1"/>
                <feComposite in2="hardAlpha" operator="out"/>
                <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"/>
                <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow"/>
                <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow" result="shape"/>
              </filter>
            </defs>
          </svg>
        </div>
      </div>

      {/* Title Section */}
      <h2 className="text-2xl font-black text-white mb-1 tracking-tight">آبشده نقدی</h2>
      <span className="text-gray-400 font-sans text-sm tracking-widest uppercase mb-8">Gold Futures</span>

      {/* Price Row */}
      <div className="flex flex-col items-center w-full mb-2">
        <div className="flex flex-wrap items-center justify-center gap-3 md:gap-4 w-full" dir="rtl">
          {/* Badge (Right in RTL) */}
          <div className="bg-[#fb923c] text-white px-4 py-1.5 rounded-xl text-sm font-bold shadow-lg whitespace-nowrap order-1">
            نرخ فعلی::
          </div>

          {/* Price (Center) */}
          <h1 className="text-4xl md:text-6xl font-black text-white tracking-wider tabular-nums order-2 mx-2">
            {formatPrice(data.price)}
          </h1>

          {/* Percent (Left in RTL) */}
          <span className={`text-xl font-mono ${changeColor} order-3 dir-ltr`}>
            ({changeText})
          </span>
        </div>
        
        <span className="text-[#666] text-sm mt-3 font-medium">آبشده</span>
      </div>

      {/* Divider */}
      <div className="w-full h-px bg-[#333] my-6"></div>

      {/* Footer Details Grid */}
      <div className="grid grid-cols-2 w-full gap-y-6 gap-x-4 md:gap-x-12 px-2" dir="rtl">
        {/* Row 1 */}
        <div className="flex items-center justify-between group">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-[#fb923c] flex items-center justify-center text-white font-bold text-sm shadow-md">
              ?
            </div>
            <span className="text-[#fbbf24] font-bold text-sm md:text-base">واحد حجمی :</span>
          </div>
          <span className="text-white font-medium text-sm md:text-base">مثقال</span>
        </div>

        <div className="flex items-center justify-between">
           <span className="text-white font-medium text-sm md:text-base order-2">ریال</span>
           <div className="flex items-center gap-2 order-1">
            <span className="text-[#fbbf24] font-bold text-sm md:text-base">واحد پولی :</span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#fbbf24]"></span>
          </div>
        </div>

        {/* Row 2 */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
             <span className="w-1.5 h-1.5 rounded-full bg-[#fbbf24] ml-1"></span>
             <span className="text-[#fbbf24] font-bold text-sm md:text-base">نوع بازار :</span>
          </div>
          <span className="text-white font-medium text-sm md:text-base">بازار داخلی</span>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-white font-medium text-sm md:text-base order-2">ایران</span>
          <div className="flex items-center gap-2 order-1">
            <span className="text-[#fbbf24] font-bold text-sm md:text-base">کشور :</span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#fbbf24]"></span>
          </div>
        </div>
      </div>
    </div>
  );
};