import React from 'react';
import { AISignal, SignalAction } from '../types';

interface SignalPanelProps {
  signal: AISignal | null;
  loading: boolean;
}

const getActionColor = (action: SignalAction) => {
  switch (action) {
    case SignalAction.STRONG_BUY:
    case SignalAction.BUY:
      return 'text-emerald-400 border-emerald-500/50 bg-emerald-900/10';
    case SignalAction.STRONG_SELL:
    case SignalAction.SELL:
      return 'text-rose-400 border-rose-500/50 bg-rose-900/10';
    default:
      return 'text-gray-400 border-gray-600/50 bg-gray-800/20';
  }
};

const formatPrice = (price: number) => new Intl.NumberFormat('fa-IR').format(price);

export const SignalPanel: React.FC<SignalPanelProps> = ({ signal, loading }) => {
  if (loading && !signal) {
    return (
      <div className="h-full min-h-[300px] rounded-2xl bg-dark-card border border-dashed border-dark-700 flex flex-col items-center justify-center p-6 animate-pulse">
        <div className="w-16 h-16 rounded-full border-4 border-gold-600 border-t-transparent animate-spin mb-4"></div>
        <p className="text-gold-400 font-mono text-lg">هوش مصنوعی در حال شکار...</p>
        <p className="text-xs text-gray-500 mt-2">Connecting to Neural Engine...</p>
      </div>
    );
  }

  if (!signal) return null;

  const actionStyle = getActionColor(signal.action);
  const isAggressive = signal.isAggressive;

  return (
    <div className="relative h-full rounded-2xl bg-dark-card border border-dark-700 p-6 flex flex-col justify-between overflow-hidden group">
      {/* Background Effects */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-gold-500/5 rounded-full blur-3xl -z-0"></div>
      
      <div className="relative z-10 w-full">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h2 className="text-gray-400 text-sm font-bold uppercase tracking-wider mb-1">سیگنال هوش مصنوعی</h2>
            <div className="flex items-center space-x-2 space-x-reverse">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
              <span className="text-xs text-green-500 font-mono">LIVE HUNTER</span>
            </div>
          </div>
          <div className="flex flex-col items-end">
             <span className="text-xs text-gray-500 mb-1">قدرت سیگنال</span>
             <div className="h-2 w-24 bg-dark-900 rounded-full overflow-hidden">
               <div 
                 className={`h-full ${signal.confidence > 70 ? 'bg-gold-500' : 'bg-blue-500'}`} 
                 style={{ width: `${signal.confidence}%` }}
               ></div>
             </div>
             <span className="text-xs font-mono text-gold-400 mt-1">{signal.confidence}%</span>
          </div>
        </div>

        <div className={`text-center py-6 border-y border-dark-700 mb-6 ${isAggressive ? 'animate-pulse' : ''}`}>
          <h3 className={`text-5xl font-black tracking-widest ${actionStyle.split(' ')[0]}`}>
            {signal.action === 'STRONG_BUY' ? 'خرید سنگین' : 
             signal.action === 'BUY' ? 'خرید' :
             signal.action === 'STRONG_SELL' ? 'فروش سنگین' :
             signal.action === 'SELL' ? 'فروش' : 'نظاره‌گر'}
          </h3>
          {isAggressive && (
            <span className="inline-block mt-2 px-3 py-1 bg-red-900/30 text-red-400 text-xs border border-red-500/30 rounded-full font-bold uppercase tracking-wider">
              حالت تهاجمی
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {/* Entry Point - Highlighted */}
          <div className="bg-dark-800 p-3 rounded-lg border border-blue-500/30 relative overflow-hidden shadow-[0_0_10px_rgba(59,130,246,0.1)]">
            <div className="absolute top-0 right-0 w-1.5 h-full bg-blue-500"></div>
            <span className="text-xs text-blue-400 font-bold block mb-1">نقطه ورود (Entry)</span>
            <div className="flex items-baseline gap-1">
               <span className="text-white font-mono font-bold text-lg">{formatPrice(signal.entryPrice)}</span>
               <span className="text-[10px] text-gray-500">ریال</span>
            </div>
          </div>
          
          <div className="bg-dark-800 p-3 rounded-lg border border-dark-700 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-1 h-full bg-rose-500/50"></div>
            <span className="text-xs text-gray-500 block mb-1">حد ضرر (Stop Loss)</span>
             <div className="flex items-baseline gap-1">
              <span className="text-rose-400 font-mono font-bold text-lg">{formatPrice(signal.stopLoss)}</span>
              <span className="text-[10px] text-gray-500">ریال</span>
            </div>
          </div>
          
          <div className="bg-dark-800 p-3 rounded-lg border border-dark-700 relative overflow-hidden">
             <div className="absolute top-0 right-0 w-1 h-full bg-emerald-500/50"></div>
            <span className="text-xs text-gray-500 block mb-1">حد سود (Take Profit)</span>
            <div className="flex items-baseline gap-1">
              <span className="text-emerald-400 font-mono font-bold text-lg">{formatPrice(signal.takeProfit)}</span>
              <span className="text-[10px] text-gray-500">ریال</span>
            </div>
          </div>
        </div>
      </div>

      <div className="relative z-10 bg-dark-900 p-4 rounded-xl border border-dashed border-dark-700">
        <p className="text-gray-300 text-sm leading-relaxed text-right font-light dir-rtl">
          <span className="text-gold-500 font-bold ml-1">تحلیل شکارچی:</span>
          {signal.reasoning}
        </p>
      </div>
    </div>
  );
};