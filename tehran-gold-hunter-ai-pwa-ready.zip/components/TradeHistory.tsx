import React from 'react';
import { AISignal } from '../types';

interface TradeHistoryProps {
  signals: AISignal[];
}

export const TradeHistory: React.FC<TradeHistoryProps> = ({ signals }) => {
  return (
    <div className="bg-dark-card rounded-2xl border border-dark-700 overflow-hidden h-[300px] flex flex-col">
      <div className="p-4 border-b border-dark-700 bg-dark-800/50">
        <h3 className="text-gray-300 font-bold text-sm">تاریخچه سیگنال‌ها</h3>
      </div>
      <div className="flex-1 overflow-y-auto p-2">
        <table className="w-full text-right text-xs md:text-sm">
          <thead className="text-gray-500 font-medium">
            <tr>
              <th className="pb-2 pr-2">زمان</th>
              <th className="pb-2">اکشن</th>
              <th className="pb-2">قیمت ورود</th>
              <th className="pb-2 text-left pl-2">قدرت</th>
            </tr>
          </thead>
          <tbody className="space-y-2">
            {[...signals].reverse().map((sig) => (
              <tr key={sig.id} className="border-b border-dark-800 last:border-0 hover:bg-dark-800/50 transition-colors">
                <td className="py-3 pr-2 font-mono text-gray-400">
                  {new Date(sig.timestamp).toLocaleTimeString('fa-IR')}
                </td>
                <td className="py-3">
                  <span className={`px-2 py-1 rounded text-xs font-bold ${
                    sig.action.includes('BUY') ? 'bg-emerald-900/30 text-emerald-400' : 
                    sig.action.includes('SELL') ? 'bg-rose-900/30 text-rose-400' : 'bg-gray-800 text-gray-400'
                  }`}>
                    {sig.action}
                  </span>
                </td>
                <td className="py-3 font-mono text-gray-300">
                  {new Intl.NumberFormat('fa-IR').format(sig.entryPrice)}
                </td>
                <td className="py-3 pl-2 text-left">
                  <div className="flex items-center justify-end">
                    <span className="text-gold-500 font-mono ml-1">{sig.confidence}%</span>
                  </div>
                </td>
              </tr>
            ))}
            {signals.length === 0 && (
               <tr>
                 <td colSpan={4} className="text-center py-8 text-gray-600">
                   هنوز سیگنالی صادر نشده است
                 </td>
               </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
